# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['D:\\ANTIGRAVITY PROJECT FOLDER\\GANN GRAPH\\desktop_app.py'],
    pathex=[],
    binaries=[],
    datas=[('dist', 'dist')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Gann_Drafting_Desk_v1',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['D:\\ANTIGRAVITY PROJECT FOLDER\\gann_icon.ico'],
)
